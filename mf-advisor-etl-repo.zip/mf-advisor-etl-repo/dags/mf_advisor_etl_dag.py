from airflow.decorators import dag
from airflow.operators.empty import EmptyOperator
from datetime import datetime, timedelta
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator

# -----------------------------
# DAG Definition
# -----------------------------
@dag(
    start_date=datetime(2025, 1, 1),
    schedule="@daily",
    catchup=False,
    tags=["customer_churn", "etl-pipeline"],
)
def mf_advisor_etl_dag():

    # Step 1: Initialize datastore
    initialize_datastore = SparkSubmitOperator(
        task_id="init_db",
        conn_id="my_spark_conn",
        application="include/scripts/mf_db_setup/mf_advisor_db_setup.py",
        execution_timeout=timedelta(minutes=30),
        retries=2,
        retry_delay=timedelta(minutes=10),
        verbose=True,
    )

    # Step 2: Dummy task (runs after init_db)
    dummy_task = EmptyOperator(
        task_id="post_init_dummy_task"
    )

    # ✅ Set dependency
    initialize_datastore >> dummy_task

    return initialize_datastore, dummy_task

# Register DAG
dag = mf_advisor_etl_dag()